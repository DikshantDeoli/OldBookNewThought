<?php

$db = new mysqli("localhost","root","","oldbooks_new_thought");

?>


